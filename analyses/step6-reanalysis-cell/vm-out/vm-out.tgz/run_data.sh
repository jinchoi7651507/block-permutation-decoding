set -u
P=../venv/bin/python
st(){ echo "$1 exit $2 $(date -u +%H:%M:%S)"; }
echo "start $(date -u)"
$P -I code/fetch_data.py data > fetch.log 2>&1; r=$?; st fetch $r; [ $r -eq 0 ] || exit 1
$P code/run_cell.py inspect --extract-root data --out out --cache > inspect.log 2>&1; r=$?; st inspect $r; [ $r -eq 0 ] || exit 1
$P code/run_cell.py gate --extract-root data --out out --cache --workers 56 > gate.log 2>&1; r=$?; st gate $r
$P code/run_cell.py select --out out > select.log 2>&1; r=$?; st select $r
for t in primary trial win600 adjacent estimated; do $P code/run_cell.py test --name $t --extract-root data --out out --cache --workers 56 > test-$t.log 2>&1; st test-$t $?; done
echo "end $(date -u)"
